PSD Template by ketraline
Tagmarker font by Pop Ovidiu Sebastian
BebasKai font by Dharma Type

Do not redistribute the PSD without credit. Images generated with the template may be used without credit.